/* Include guard intentionally left out. */

#ifdef __cplusplus
}
#endif

#include "flatcc/portable/pdiagnostic_pop.h"
